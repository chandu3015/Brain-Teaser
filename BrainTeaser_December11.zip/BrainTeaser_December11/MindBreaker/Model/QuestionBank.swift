
import Foundation

class QuestionBank
{
    var list = [Question]()
    
    var intn1 = 0
    var intn2 = 0
    var opp = 0
    var correctAnser = 0
    var wrongAnswer = 0
    var truOrFal = 0
    var  quest = "question"
    var ans = true
    var symbol = "+"
    
    
    init (level : Int)
    {
        for  index in 1...300
        {
            opp = Int.random(in: 1...4)
            truOrFal = Int.random(in: 0...1)
            
            print("generating question \(index)")
            if(level == 1)
            {
                intn1 = Int.random(in: 11...20)
                intn2 = Int.random(in: 11...20)
                
                correctAnser = getCorrectAnser(num1: intn1, num2: intn2, opp: opp)
                wrongAnswer = getWrongAnser(num1: intn1, num2: intn2, opp: opp, lb: -3, ub: 3)
                
            }
            else if(level == 2)
            {
                intn1 = Int.random(in: 21...30)
                intn2 = Int.random(in: 21...30)
                
                correctAnser = getCorrectAnser(num1: intn1, num2: intn2, opp: opp)
                wrongAnswer = getWrongAnser(num1: intn1, num2: intn2, opp: opp, lb: -2, ub: 2)
                
            }
            else
            {
                intn1 = Int.random(in: 1...10)
                intn2 = Int.random(in: 1...10)
                
                correctAnser = getCorrectAnser(num1: intn1, num2: intn2, opp: opp)
                wrongAnswer = getWrongAnser(num1: intn1, num2: intn2, opp: opp, lb: -5, ub: 5)
                
            }
            
            
            
            
            symbol = getSymbol(opp : opp)
            
            if (truOrFal == 0)
            {
                quest = "\(intn1)  \(symbol)  \(intn2)  = \(wrongAnswer)"
                ans = false
            }
            else
            {
                quest = "\(intn1)  \(symbol)  \(intn2)  = \(correctAnser)"
                ans = true
                
            }
            
            
            
            // Creating a quiz item and appending it to the list
            let item = Question(text: quest , CorrectAnswer: ans, Solution : correctAnser)
            
            // Add the Question to the list of questions
            list.append(item)
            
        }
        
        
        
    }
    
    func   getCorrectAnser(num1 : Int , num2 : Int , opp : Int ) -> Int
    {
        var res = 0
        switch(opp)
        {
        case 1 :  res = num1 + num2
        
            break
            
        case 2 :  res = num1 - num2
        
            break
            
        case 3 : res = num1 * num2
            break
            
        case 4 :
            res = num1 / num2
            break
            
        default : break
        }
        
        return res
    }
    
    func   getWrongAnser(num1 : Int , num2 : Int , opp : Int , lb : Int, ub : Int ) -> Int
    {
        var res = 0
        var  randomArray = [IntegerLiteralType]()

        if(lb == -3 && ub == 3){
            randomArray.append(-3)
            randomArray.append(-2)
            randomArray.append(-1)
            randomArray.append(1)
            randomArray.append(2)
            randomArray.append(3)
        }else if(lb == -2 && ub == 2){
            randomArray.append(-2)
            randomArray.append(-1)
            randomArray.append(1)
            randomArray.append(2)
        }else{
            randomArray.append(-5)
            randomArray.append(-4)
            randomArray.append(-3)
            randomArray.append(-2)
            randomArray.append(-1)
            randomArray.append(1)
            randomArray.append(2)
            randomArray.append(3)
            randomArray.append(4)
            randomArray.append(5)
        }
        switch(opp)
        {
        case 1 :  res = num1 + num2 + randomArray[Int.random(in: 0...ub-lb-1)]
        
            break
            
        case 2 :  res = num1 - num2 + randomArray[Int.random(in: 0...ub-lb-1)]
        
            break
            
        case 3 : res = num1 * num2 + randomArray[Int.random(in: 0...ub-lb-1)]
        
            break
            
        case 4 :
            res = num1 / num2 + randomArray[Int.random(in: 0...ub-lb-1)]
            
            break
            
        default : break
            
        }
        
        return res
    }
    
    func   getSymbol( opp : Int ) -> String
    {
        var res =  "+"
        switch(opp)
        {
        case 1 :  res = "+"
        
            break
            
        case 2 :  res = "-"
        
            break
            
        case 3 : res = "*"
        
            break
            
        case 4 :
            
            res = "/"
            
            break
            
        default : break
            
        }
        
        return res
    }
    
}
