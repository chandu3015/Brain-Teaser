//
//  ScoreRecords.swift
//  MindBreaker
//
//  Created by Project on 10/18/18.
//  Copyright © 2018 techMightes. All rights reserved.
//
/*
import Foundation
class ScoreRecords
{
    var score : Int = 0
    var level : Int = 0
    var timeOfPlay : Date = Date()
    
    
}
*/
