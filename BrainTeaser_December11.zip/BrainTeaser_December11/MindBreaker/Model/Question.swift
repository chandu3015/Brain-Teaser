
import Foundation

class Question
{
    let question : String
    let answer : Bool
    let sol : Int
    init(text : String , CorrectAnswer : Bool , Solution : Int)
    {
        question = text
        answer = CorrectAnswer
        sol = Solution
    }
}



