//
//  resultVIewCellControllerTableViewCell.swift
//  MindBreaker
//
//  Created by Project on 10/15/18.
//  Copyright © 2018 techMightes. All rights reserved.
//

import UIKit

class resultVIewCellControllerTableViewCell: UITableViewCell {
    
    @IBOutlet weak var que: UILabel!
    
    @IBOutlet weak var userAnswer: UILabel!
    
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var sol: UILabel!
    @IBOutlet weak var correctAnswer: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
