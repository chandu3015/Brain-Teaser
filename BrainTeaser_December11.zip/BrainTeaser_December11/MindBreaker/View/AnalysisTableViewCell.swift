//
//  AnalysisTableViewCell.swift
//  MindBreaker
//
//  Created by Rajeev Reddy Bathula on 11/25/18.
//  Copyright © 2018 techMightes. All rights reserved.
//

import UIKit

class AnalysisTableViewCell: UITableViewCell {

    @IBOutlet weak var playedDate: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    @IBOutlet weak var levelOutlet: UILabel!
    
    @IBOutlet weak var scoreOutlet: UILabel!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
