//
//  QuizViewController.swift
//  MindBreaker
//
//  Created by Project on 10/15/18.
//  Copyright © 2018 techMightes. All rights reserved.
//

import UIKit
import CoreData
import AVFoundation

class QuizViewController: UIViewController {

    @IBOutlet weak var MaxScoreLAbel: UILabel!
    var level:Int = -1
    var buttonColor:UIColor?
     var scoreRecordArray = [ScoreRecords]();
    //Place your instance variables here
    var allQuestions:QuestionBank? //= QuestionBank()
    var pickedAnswer : Bool = false
    var questionNumber : Int = 0
    var score : Int = 0
    var validateAnswer: Bool = false
    @IBOutlet weak var falseButtonOutlet: UIButton!
    @IBOutlet weak var trueButtonOutlet: UIButton!
    @IBOutlet weak var timer: UILabel!
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    //timer Related Variables
     var maxSeconds: Int = 30
    var seconds: Int = 30
    var tim = Timer()
    
    
    
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet var progressBar: UIView!
    @IBOutlet weak var progressLabel: UILabel!
    // make sure to add this sound to your project
    var wronganswer = AVAudioPlayer()
    var correctanswer = AVAudioPlayer()
    var gameover = AVAudioPlayer()
    
    let maximumQuestion = 1000 //13
    var allPickedAnswers = [Bool] ()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        allQuestions = QuestionBank(level: self.level)
        
        progressBar.isHidden = true
        
        scheduleTimer()
        
        buttonColor = trueButtonOutlet.backgroundColor
        
        questionLabel.text = allQuestions!.list[questionNumber].question
        updateUI()
        
//        trueButtonOutlet.backgroundColor = UIColor.orange
//        falseButtonOutlet.backgroundColor = UIColor.orange
        
        let boosound=Bundle.main.path(forResource: "sma4_boo", ofType: "wav")
        let coinsound=Bundle.main.path(forResource: "smb3_coin", ofType: "wav")
        let gameoversound=Bundle.main.path(forResource: "smb_gameover", ofType: "wav")
        do
        {
            wronganswer = try AVAudioPlayer(contentsOf : URL(fileURLWithPath: boosound!))
            correctanswer = try AVAudioPlayer(contentsOf : URL(fileURLWithPath: coinsound!))
            gameover = try AVAudioPlayer(contentsOf : URL(fileURLWithPath: gameoversound!))
        }
        catch
        {
            print(error)
        }
        wronganswer.prepareToPlay()
        correctanswer.prepareToPlay()
        gameover.prepareToPlay()
    }
 
    
    func  scheduleTimer()
    {
        tim = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.timerAction), userInfo: nil, repeats: true)
        
        
    }
    
    @objc func timerAction()
    {
        seconds = seconds - 1
        timer.text = "\(seconds)"
        //progressBar.frame.size.width = (view.frame.size.width/CGFloat(maxSeconds))*CGFloat(seconds)
        
        if(seconds == 0)
        {
            tim.invalidate()
            
            timer.text = "Time Up!"
            timeUp()
        }
        
    }
    
    func timeUp()
    {
        
        saveData()
        
        
        let alert = UIAlertController(title: "Time Up!", message: "Sorry you are timed out!", preferredStyle: .alert)
        
        let restartAction1 = UIAlertAction(title: "View Score" , style: .default , handler : {
            (UIAlertAction) in
           self.showResults()
        })
        alert.addAction(restartAction1)
        gameover.play()
        present(alert,animated: true, completion: nil)
        
    }
    
    func showResults()
    {

        performSegue(withIdentifier: "viewScore", sender: self)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "viewScore"
        {
            let destinationVC = segue.destination  as! ScoreViewController

            destinationVC.allQuestions = allQuestions
            destinationVC.numbeOfQuesAnswered = allPickedAnswers.count
            destinationVC.pickedAns = allPickedAnswers
            destinationVC.level = self.level
            destinationVC.score = self.score
        }
    }
    
    
    
    @IBAction func answerPressed(_ sender: AnyObject) {
        
        
        
        if(sender.tag == 1)
        {
            pickedAnswer = true
        }
        else
        {
            pickedAnswer = false
        }
        
       
        allPickedAnswers.append(pickedAnswer)
        
        
        
        checkAnswer()
        
       // sleep(2)
        
        questionNumber = questionNumber + 1
        
        nextQuestion()
        
//         trueButtonOutlet.addTarget(self, action: Selector("holdRelease:"), for: UIControl.Event.touchUpInside)

        
    }
    
    
    func updateUI() {
       // scoreLabel.text = "Score : \(score) out of \(questionNumber)"
        let wrongAns = questionNumber - score
        let scored:Int
        if(level == 0){
          scored = (score*10) - (wrongAns*5)
        }else if(level == 1){
          scored = (score*20) - (wrongAns*7)
        }else{
          scored = (score*30) - (wrongAns*10)
        }
        
        scoreLabel.text = "Score : \(scored)"
        progressLabel.text = "At question: \(questionNumber+1)"

         //scoreLabel.text = "Score : \(score)"
        //progressLabel.text = "\(questionNumber) / \(maximumQuestion)"
       // progressBar.frame.size.width = (view.frame.size.width/CGFloat(maximumQuestion))*CGFloat(questionNumber)
        
        
        
    }
    
    
    func nextQuestion() {
        
       
        if(questionNumber <= maximumQuestion - 1)
        {
            
            questionLabel.text = allQuestions!.list[questionNumber].question
            updateUI()
        }
        else
        {
            
            saveData()
            
            
            let alert = UIAlertController(title: "Awesome!", message: "YOu have FInished!", preferredStyle: .alert)
            
            let restartAction1 = UIAlertAction(title: "viewResults" , style: .default , handler : {
                (UIAlertAction) in
                self.showResults()
            })
            alert.addAction(restartAction1)
            present(alert,animated: true, completion: nil)
            /*
             let alert = UIAlertController(title: "Awesome!", message: "YOu have FInished!", preferredStyle: .alert)
             
             let restartAction1 = UIAlertAction(title: "restart" , style: .default , handler : {
             (UIAlertAction) in
             self.startOver()
             })
             alert.addAction(restartAction1)
             present(alert,animated: true, completion: nil) */
        }
//        trueButtonOutlet.backgroundColor = UIColor.orange
//        falseButtonOutlet.backgroundColor = UIColor.orange
    }
    

    
    
    func checkAnswer() {
        
        
        
        //target functions
       
        
        if(pickedAnswer==allQuestions!.list[questionNumber].answer)
        {
            print("correct!")
            //validateAnswer = true;
            score = score + 1
            
            if pickedAnswer == true
            {
                correctanswer.play()
                UIView.animate(withDuration: 1, animations: {
                    self.trueButtonOutlet.backgroundColor = UIColor.green
                },completion: { _ in
                    self.trueButtonOutlet.backgroundColor = self.buttonColor
                })
               
            }
            else if pickedAnswer == false
            {
                correctanswer.play()
                UIView.animate(withDuration: 1, animations: {
                    self.falseButtonOutlet.backgroundColor = UIColor.green
                },completion: { _ in
                    self.falseButtonOutlet.backgroundColor = self.buttonColor
                })
                
            }
            
        }
        else
        {
            print("wrong!")
            
            if pickedAnswer == true{
                wronganswer.play()
                UIView.animate(withDuration: 1, animations: {
                    self.trueButtonOutlet.backgroundColor = UIColor.red
                },completion: { _ in
                    self.trueButtonOutlet.backgroundColor = self.buttonColor
                })
            }else if pickedAnswer == false{
                wronganswer.play()
                UIView.animate(withDuration: 1, animations: {
                    self.falseButtonOutlet.backgroundColor = UIColor.red
                },completion: { _ in
                    self.falseButtonOutlet.backgroundColor = self.buttonColor
                })
            }
        }
        
        
        
    
    }
    
    
    func startOver() {
        questionNumber = 0
        score = 0
        nextQuestion()
        updateUI()
    }
    
    
    func saveData()
    {
        let newScoreRecord =  ScoreRecords(context: self.context)
        newScoreRecord.score = Int64(Int32(self.score))
        newScoreRecord.outOf = Int64(Int32(self.questionNumber))
        
       // newScoreRecord.merit = Double(Int32(self.score))/Double(Int32(self.questionNumber))
        let wrongAttempted = self.questionNumber - self.score
        if(self.level == 0){
            newScoreRecord.merit = Int64((Int32(self.score)*10) - (Int32(wrongAttempted)*5))
        }else if(self.level == 1){
            newScoreRecord.merit = Int64((Int32(self.score)*20) - (Int32(wrongAttempted)*7))
        }else{
            newScoreRecord.merit = Int64((Int32(self.score)*30) - (Int32(wrongAttempted)*10))
        }
        
        print("merit")
       print(Double(Int32(self.score))/Double(Int32(self.questionNumber)))
        
        newScoreRecord.level = Int16(self.level)
        
        newScoreRecord.timeOfPlay = Date()
        
        do
        {
        
          
           try  context.save()
            
        }
        catch
        {
            print("Error saving to DataBase")
        }
        
        
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        // Show the Navigation Bar
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        loadMaxScore()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        // Hide the Navigation Bar
        self.navigationController?.setNavigationBarHidden(false, animated: false)
    }
    
    func  loadMaxScore(){
        let request : NSFetchRequest <ScoreRecords> = ScoreRecords.fetchRequest()
        do
        {
         
            request.predicate = NSPredicate(format: "level == \(level ?? -1)")
            request.sortDescriptors = [NSSortDescriptor(key: "merit", ascending: false)]
            scoreRecordArray =  try context.fetch(request)
            //            let maxScoreDisplay = String(scoreRecordArray[0].score)+" out of "+String(scoreRecordArray[0].outOf)
            if(scoreRecordArray.count>0){
            MaxScoreLAbel.text = "Best Score : \(scoreRecordArray[0].merit)"
            }else
            {
            MaxScoreLAbel.text = "Best Score : 0"
            }
        }
        catch
        {
            print("Exception In catching")
        }
    }

}
