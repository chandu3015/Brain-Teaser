//
//  ResultsViewController.swift
//  MindBreaker
//
//  Created by Project on 10/15/18.
//  Copyright © 2018 techMightes. All rights reserved.
//

import UIKit

class ResultsViewController: UITableViewController {
    
    
    var allQuestions : QuestionBank?
    var numbeOfQuesAnswered : Int?
    
    var pickedAns = [Bool]()
    
    var level : Int?
    
    
    var qu: String?
    var an: Bool?
    var tp: String?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
         //self.navigationItem.setHidesBackButton(true, animated:true);
        self.title = "Score Details"
        
    }
   
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return numbeOfQuesAnswered!
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: resultVIewCellControllerTableViewCell = tableView.dequeueReusableCell(withIdentifier: "resultsCell", for: indexPath) as! resultVIewCellControllerTableViewCell
        
        qu = allQuestions?.list[indexPath.row].question
        an = allQuestions?.list[indexPath.row].answer
        var x: Int = (allQuestions?.list[indexPath.row].sol)!
        print(qu);
        print(an);
        print(x);
        
        cell.correctAnswer.text = "Correct Answer : \(an ?? false)"
        
        cell.que.text = "Q: \(allQuestions?.list[indexPath.row].question ?? "Ques")"
        
        cell.correctAnswer.text = "Correct Answer : \(an ?? false)"
        
        cell.userAnswer.text = "User Answer : \(pickedAns[indexPath.row])"
        
        if(an == pickedAns[indexPath.row])
        {
            cell.img.image = UIImage(named: "right-88.png")
        }
        else
        {
            cell.img.image = UIImage(named: "cross2.png")
            
        }
        
        return cell
    }
    
    @IBAction func AnalysisButtonPressed(_ sender: Any) {
        performSegue(withIdentifier: "results2Score", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "results2Score"
        {
            let destinationVC = segue.destination  as! analysisTableViewController
            
            destinationVC.level = self.level!
            
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        // return UITableView.automaticDimension
        return 140
        
    }
    
    override func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 0
    }
    
    
    
    
}
