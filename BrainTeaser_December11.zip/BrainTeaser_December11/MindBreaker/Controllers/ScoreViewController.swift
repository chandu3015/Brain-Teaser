//
//  ScoreViewController.swift
//  MindBreaker
//
//  Copyright © 2018 techMightes. All rights reserved.
//

import UIKit
import CoreData

class ScoreViewController: UIViewController {
    var allQuestions : QuestionBank?
    var numbeOfQuesAnswered : Int?
    var score : Int?
     let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var pickedAns = [Bool]()
    
    @IBOutlet weak var historyButtonOutlet: UIButton!
    @IBOutlet weak var viewScoreButtonOutlet: UIButton!
    @IBOutlet weak var playAgainbuttonOutlet: UIButton!
    @IBOutlet weak var scoreMessage: UILabel!
    @IBOutlet weak var levelOutlet: UILabel!
    var levelString : String?
    var level : Int?
     var scoreRecordArray = [ScoreRecords]();
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.setHidesBackButton(true, animated:true);
        // Do any additional setup after loading the view.
    }
    
    @IBAction func scoreDetailsAction(_ sender: Any) {
        self.showResults()
    }
    
    @IBAction func playAgainAction(_ sender: Any) {
         performSegue(withIdentifier: "playAgain", sender: self)
    }
    @IBAction func historyActionButton(_ sender: Any) {
         performSegue(withIdentifier: "results2Score", sender: self)
    }
    @IBOutlet weak var ResultsLabel: UILabel!
    
    
    @IBOutlet weak var maxScore: UILabel!
    
    func showResults()
    {
        
        performSegue(withIdentifier: "goToResultsViewController", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToResultsViewController"
        {
            let destinationVC = segue.destination  as! ResultsViewController
            
            destinationVC.allQuestions = self.allQuestions
            destinationVC.numbeOfQuesAnswered = self.numbeOfQuesAnswered
            destinationVC.pickedAns = self.pickedAns
            destinationVC.level = self.level
        }
        
        if segue.identifier == "results2Score"
        {
            let destinationVC = segue.destination  as! analysisTableViewController
            
            destinationVC.level = self.level!
            
        }
    
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        //delte()
        if(level == 0){
            var unwrappedQues = self.numbeOfQuesAnswered!
            var unwrappedScore = self.score!
            let wrongAttempted = unwrappedQues-unwrappedScore
            //ResultsLabel.text = "\(unwrappedScore) out of \(unwrappedQues)"
            ResultsLabel.text = String((Int32(unwrappedScore)*10) - (Int32(wrongAttempted)*5))
            levelString = "Easy"
        }else if(level == 1) {
            levelString = "Medium"
            var unwrappedQues = self.numbeOfQuesAnswered!
            var unwrappedScore = self.score!
            let wrongAttempted = unwrappedQues-unwrappedScore
            //ResultsLabel.text = "\(unwrappedScore) out of \(unwrappedQues)"
            ResultsLabel.text = String((Int32(unwrappedScore)*20) - (Int32(wrongAttempted)*7))
        }else{
            levelString = "Hard"
            var unwrappedQues = self.numbeOfQuesAnswered!
            var unwrappedScore = self.score!
            let wrongAttempted = unwrappedQues-unwrappedScore
            //ResultsLabel.text = "\(unwrappedScore) out of \(unwrappedQues)"
            ResultsLabel.text = String((Int32(unwrappedScore)*30) - (Int32(wrongAttempted)*10))
        }
        let leveltemp = levelString as! String
        loadScoreDetails()
        self.navigationController?.setNavigationBarHidden(true, animated: true)



        scoreMessage.text = "Your score at level - \(leveltemp)"

        historyButtonOutlet.layer.cornerRadius = 10
        historyButtonOutlet.clipsToBounds = true
        viewScoreButtonOutlet.layer.cornerRadius = 10
        viewScoreButtonOutlet.clipsToBounds = true
        playAgainbuttonOutlet.layer.cornerRadius = 10
        playAgainbuttonOutlet.clipsToBounds = true
        
    }
    
  
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        // Hide the Navigation Bar
        self.navigationController?.setNavigationBarHidden(false, animated: false)
    }
    
    func  loadScoreDetails(){
        let request : NSFetchRequest <ScoreRecords> = ScoreRecords.fetchRequest()
        do
        {
            print("Level is \(level!)")
            request.predicate = NSPredicate(format: "level == \(level ?? -1)")
            request.sortDescriptors = [NSSortDescriptor(key: "merit", ascending: false)]
            scoreRecordArray =  try context.fetch(request)
//            let maxScoreDisplay = String(scoreRecordArray[0].score)+" out of "+String(scoreRecordArray[0].outOf)
          
            maxScore.text = "Best Score : \(scoreRecordArray[0].merit)"
        }
        catch{
            print("Exception In catching")
        }
    }
    
    func delte(){
        let fetchRequest: NSFetchRequest<ScoreRecords> = ScoreRecords.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "merit==0")
        let objects = try! context.fetch(fetchRequest)
        for obj in objects {
            context.delete(obj)
        }

        do {
            try context.save() // <- remember to put this :)
        } catch {
            // Do something... fatalerror
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
