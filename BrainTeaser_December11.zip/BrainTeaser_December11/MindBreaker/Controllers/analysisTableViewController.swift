//
//  analysisTableViewController.swift
//  MindBreaker
//
//  Created by Project on 10/17/18.
//  Copyright © 2018 techMightes. All rights reserved.
//

import UIKit
import CoreData

class analysisTableViewController: UITableViewController {
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var levelsArray = ["Easy" , "Medium" , "Hard"]
    
    var scoreRecordArrayForLevelEasy = [ScoreRecords]();
    var scoreRecordArrayForLevelMedium = [ScoreRecords]();
    var scoreRecordArrayForLevelHard = [ScoreRecords]();
    
    var level : Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadScoreDetails()
        
    }
    
    func  loadScoreDetails(){
        
        do
        {
            //print("Level is \(level!)")
            
          let request : NSFetchRequest <ScoreRecords> = ScoreRecords.fetchRequest()
          request.predicate = NSPredicate(format: "level == 0")
          request.sortDescriptors = [NSSortDescriptor(key: "timeOfPlay", ascending: false)]
          scoreRecordArrayForLevelEasy =  try context.fetch(request)
            
          let request2 : NSFetchRequest <ScoreRecords> = ScoreRecords.fetchRequest()
          request2.predicate = NSPredicate(format: "level == 1")
          request2.sortDescriptors = [NSSortDescriptor(key: "timeOfPlay", ascending: false)]
          scoreRecordArrayForLevelMedium =  try context.fetch(request2)
           
            
          let request3 : NSFetchRequest <ScoreRecords> = ScoreRecords.fetchRequest()
          request3.predicate = NSPredicate(format: "level == 2")
          request3.sortDescriptors = [NSSortDescriptor(key: "timeOfPlay", ascending: false)]
          scoreRecordArrayForLevelHard =  try context.fetch(request3)
            
          
            
        }
        catch{
            print("Exception In catching")
        }
    }
    
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return levelsArray.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(section == 0){
          return  scoreRecordArrayForLevelEasy.count
        }else if(section == 1){
           return scoreRecordArrayForLevelMedium.count
        }
    return scoreRecordArrayForLevelHard.count

    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if(section == 0){
            return  levelsArray[0]
        }else if(section == 1){
            return levelsArray[1]
        }
        return levelsArray[2]
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "historyCell", for: indexPath) as! AnalysisTableViewCell
        
        if(indexPath.section == 0){
            let localDate : String = getLocalDate(date: scoreRecordArrayForLevelEasy[indexPath.row].timeOfPlay!)
                //        cell.textLabel?.text = "\(localDate) --->  \(scoreRecordArray[indexPath.row].score)--->\(scoreRecordArray[indexPath.row].level)"
            cell.playedDate.text = "Date: \(localDate)"
            //cell.scoreOutlet.text = "Scored: \(scoreRecordArray[indexPath.row].score) out of \(scoreRecordArray[indexPath.row].outOf)"
            cell.scoreOutlet.text = "Scored: \(scoreRecordArrayForLevelEasy[indexPath.row].merit)"
            cell.levelOutlet.text = "Level: Easy"
            
        }else if(indexPath.section == 1){
            let localDate : String = getLocalDate(date: scoreRecordArrayForLevelMedium[indexPath.row].timeOfPlay!)
            //        cell.textLabel?.text = "\(localDate) --->  \(scoreRecordArray[indexPath.row].score)--->\(scoreRecordArray[indexPath.row].level)"
            cell.playedDate.text = "Date: \(localDate)"
            //cell.scoreOutlet.text = "Scored: \(scoreRecordArray[indexPath.row].score) out of \(scoreRecordArray[indexPath.row].outOf)"
            cell.scoreOutlet.text = "Scored: \(scoreRecordArrayForLevelMedium[indexPath.row].merit)"
            cell.levelOutlet.text = "Level: Medium"
            
        }else if(indexPath.section == 2){
            let localDate : String = getLocalDate(date: scoreRecordArrayForLevelHard[indexPath.row].timeOfPlay!)
            //        cell.textLabel?.text = "\(localDate) --->  \(scoreRecordArray[indexPath.row].score)--->\(scoreRecordArray[indexPath.row].level)"
            cell.playedDate.text = "Date: \(localDate)"
            //cell.scoreOutlet.text = "Scored: \(scoreRecordArray[indexPath.row].score) out of \(scoreRecordArray[indexPath.row].outOf)"
            cell.scoreOutlet.text = "Scored: \(scoreRecordArrayForLevelHard[indexPath.row].merit)"
            cell.levelOutlet.text = "Level: Hard"
        }
        
        return cell
    }
    
    func getLocalDate(date: Date) -> String
    {
        let date = date;
        let dateFormatter = DateFormatter()
        //To prevent displaying either date or time, set the desired style to NoStyle.
        dateFormatter.timeStyle = DateFormatter.Style.medium //Set time style
        dateFormatter.dateStyle = DateFormatter.Style.medium //Set date style
        dateFormatter.timeZone = NSTimeZone() as TimeZone
        let localDate = dateFormatter.string(from: date as Date)
        
        return localDate
    }
    
    
    //temperorily added to delete records while testing
    /*
     override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
     context.delete(scoreRecordArray[indexPath.row])
     do
     {
     try context.save()
     }
     catch
     {
     print("Error caught while delete and ave")
     }
     }
     */
    
 
}
