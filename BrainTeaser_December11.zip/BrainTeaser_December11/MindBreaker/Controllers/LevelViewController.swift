//
//  LevelViewController.swift
//  MindBreaker
//
//  Created by Project on 10/18/18.
//  Copyright © 2018 techMightes. All rights reserved.
//

import UIKit

class LevelViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    @IBOutlet weak var startButton: UIButton!
    
    var levels = ["Easy" , "Medium" , "Hard"]
    
    var level : Int = 0

    @IBOutlet weak var levelPicker: UIPickerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.setHidesBackButton(true, animated:true);
        startButton.layer.cornerRadius = 10
        startButton.clipsToBounds = true
        self.levelPicker.delegate = self
        self.levelPicker.dataSource = self
        // Do any additional setup after loading the view.
    }

    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        // Show the Navigation Bar
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        // Hide the Navigation Bar
        self.navigationController?.setNavigationBarHidden(false, animated: false)
    }
    
    
    @IBAction func startPressed(_ sender: Any) {
        performSegue(withIdentifier: "welcome2Quiz", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "welcome2Quiz"
        {
            let nav = segue.destination as! UINavigationController
            
            let destinationVC = nav.topViewController  as! QuizViewController
            
            destinationVC.level = self.level
            
            
        }
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
       return levels.count
        //return 3
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        print("row is \(row)")
        return levels[row]
       // return "test"
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        print("selected row is \(row)")
        level = row
    }
    
}
